const { comparepasswrod } = require("../helpers/Comparepassword");
const { hashpass } = require("../helpers/HashPass");
const User = require("../model/Usermodel");
const jwt=require("jsonwebtoken")
const crypto=require("crypto");
const sendData = require("../config/mail");
const { ForgotFormat } = require("../utils/ForgotFormat");

exports.create =async (req,res)=>{
    try {
        const {name,email,password,cpassword}=req.body;
        const IsMmail =await User.findOne({email:email})
        if(IsMmail){
            res.json("Email Already Register😫😫")
        }
        const hashpas=await hashpass(password,cpassword)
        const data=await User.create({
            name,
            email,
            password:hashpas,
            cpassword:hashpas
        })
        if(data){
            req.flash('info',"signup Successfully! yeehh login now ...")
           res.redirect("/signin")
        }
    } catch (error) {
        console.log(error);
    }
}
exports.signin =async (req,res)=>{
    const {email,password}=req.body;
    if(email =="" || password ==""){
        req.flash('info',"please enter fileds!")
    }
    const ExitUser=await User.findOne({email:email})
    if(!ExitUser){
        // res.send("Email Id does Not exit🤣🤣🤣")
        req.flash('info',"not exist")
        res.redirect('/signin')
    }
    const Ismatch=await comparepasswrod(password,ExitUser.password)
    if(!Ismatch){
        req.flash('info',"password not match")
        res.send("password Not match")
    }
    const token =jwt.sign({
        userid:ExitUser._id,
        userrole:ExitUser.role_id
    },
    "yeskey",
    {expiresIn:"1h"}
     )
     res.cookie("token",token,{httpOnly:true})
     res.cookie("user",ExitUser,{httpOnly:true}).redirect("/")
     console.log(token);
}
exports.Forgot=async(req,res)=>{
   try {
     function generateOtp(length = 6) {
         const otp = crypto.randomInt(0, Math.pow(10, length)).toString();
         return otp.padStart(length, "0");
     }
     const {email}=req.body;
     const Exit=await User.findOne({email:email})
     if(!Exit){
         res.json("User Not Found")
     }
     const otp=generateOtp();
     sendData(Exit.email,"Forget Your Password",ForgotFormat(Exit.email,otp));
     return res.json("Your Forgot password link successfully send your mail")
   } catch (error) {
    console.log(error);
   }
}